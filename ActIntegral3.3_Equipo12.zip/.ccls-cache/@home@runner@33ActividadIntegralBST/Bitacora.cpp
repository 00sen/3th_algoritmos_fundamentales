#include "Bitacora.h"

// https://cplusplus.com/reference/fstream/ifstream/
/* Leemos el archivo que contiene todos los registros y
creamos un objeto de la clase registro para cada uno */

// COMPLEJIDAD O(n)
void Bitacora::leerArchivo(std::string filePath) {
  std::string month, day, hours, minutes, seconds, ipAdd, port, error;
  int dia, puerto;
  int numRecords = 0;
  std::ifstream file(filePath);
  if (!file.good()) {
    file.close();
    throw std::invalid_argument("File not found");
  } else {
    while (!file.eof()) {
      std::getline(file, month, ' ');
      std::getline(file, day, ' ');
      std::getline(file, hours, ':');
      std::getline(file, minutes, ':');
      std::getline(file, seconds, ' ');
      std::getline(file, ipAdd, ':');
      std::getline(file, port, ' ');
      std::getline(file, error);
      numRecords++;
      // crear un objeto de la clase Registro
      Registro tmpRec(month, day, hours, minutes, seconds, ipAdd, port, error);

      vectorRegistros.push_back(tmpRec);
    }
    file.close();
  }
}

void Bitacora::heapify(std::vector<Registro> &A, int n, int k) {
  // elemento mas grande
  int largest = k;
  // hijo izquierdo
  int left = 2 * k + 1;
  // hijo derecho
  int right = 2 * k + 2;
  // Si el hijo izquierdo es mas grande que la raiz
  if (left < n && A[left] > A[largest])
    largest = left;
  // Si el hijo derecho es mas grande que la raiz
  if (right < n && A[right] > A[largest])
    largest = right;
  // Si el mas grande no es la raiz
  if (largest != k) {
    std::swap(A[k], A[largest]);
    // Recursivamente se llama a reacomodo hacia abajo
    heapify(A, n, largest);
  }
}

void Bitacora::heapSort() {

  std::vector<Registro> &A = vectorRegistros;
  int n = vectorRegistros.size();

  // 1. Construir el Heap a partir de la lista
  for (int i = n / 2 - 1; i >= 0; i--) {
    heapify(A, n, i);
  }
  // 2. Extraer elemento por elemento del heap
  for (int i = n - 1; i > 0; i--) {
    // intercambiar raiz con la ultima hoja
    std::swap(A[0], A[i]);
    heapify(A, i, 0);
  }
}

// Imprime todos los registros disponibles en el vector
void Bitacora::printAll() {
  for (int i = 0; i < vectorRegistros.size(); ++i) {
    std::cout << vectorRegistros[i].getAll() << std::endl;
  }
}

// Escribe en un archivo todo el vector de registros
void Bitacora::writeAll() {
  std::ofstream archivo("bitacora_ordenada.txt");
  if (!archivo) {
    std::cout << "No se pudo abrir el archivo\n";
  } else {
    for (int i = 0; i < vectorRegistros.size(); ++i) {
      archivo << vectorRegistros[i].getAll() << std::endl;
    }
  }
  archivo.close();
}

// Devuelve el indice de la primera ocurrencia del registro dado
int Bitacora::binarySearchFirst(Registro registro) {
  int l = 0;
  int r = vectorRegistros.size() - 1;
  int result = -1;

  while (l <= r) {
    int mid = l + (r - l) / 2;
    if (vectorRegistros[mid] == registro) {
      result = mid;
      r = mid - 1;
    } else if (vectorRegistros[mid] < registro) {
      l = mid + 1;
    } else {
      r = mid + 1;
    }
  }
  return result;
}

// Devuelve el indice la ultima ocurrencia del Registro dado
int Bitacora::binarySearchLast(Registro registro) {
  int l = 0;
  int r = vectorRegistros.size() - 1;
  int result = -1;

  while (l <= r) {
    int mid = l + (r - l) / 2;

    if (vectorRegistros[mid] == registro) {
      result = mid;
      l = mid + 1;
    } else if (vectorRegistros[mid] < registro) {
      l = mid + 1;
    } else {
      r = mid - 1;
    }
  }
  return result;
}

// En un AVL se crea un par con la cantidad de ocurrencias en el txt dado por
// cada ip existente
void Bitacora::insertInAvl() {
  int primeraOcurrencia = 0;

  while (primeraOcurrencia < vectorRegistros.size()) {
    int segundaOcurrencia = binarySearchLast(
        vectorRegistros[primeraOcurrencia]); // Creacion del par con la cantidad
                                             // de ocurrencias
    std::pair<int, std::string> par = {
        segundaOcurrencia - primeraOcurrencia + 1,
        vectorRegistros[primeraOcurrencia].getIpString()};
    avl.insert(par);
    primeraOcurrencia = segundaOcurrencia + 1; // Se prosigue con la siguiente
                                               // ip
  }
}