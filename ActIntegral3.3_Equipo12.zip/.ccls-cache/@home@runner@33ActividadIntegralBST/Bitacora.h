#ifndef _BITACORA_H_
#define _BITACORA_H_

#include <algorithm>
#include <ctime>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "AVL.h"
#include "MinHeap.h"
#include "Registro.h"

class Bitacora {
private:
  struct tm dateStruct;
  std::vector<std::string> months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                     "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

public:
  std::vector<Registro> vectorRegistros;  // Creamos heap
  void leerArchivo(std::string filePath); // O(n)
  int busquedaBinaria(std::vector<Registro> &V, int key,
                      unsigned int &compara); // O(log2n)

  void heapSort();                                      // O(nlogn)
  void heapify(std::vector<Registro> &A, int n, int k); // O(logn)
  void printAll();                                      // O(n)
  void writeAll();                                      // O(n)
  int binarySearchFirst(Registro registro);             // O(logn)
  int binarySearchLast(Registro registro);              // O(logn)
  void insertInAvl();                                   // O(logn)

  AVLTree<std::pair<int, std::string>> avl;
};

#endif // _BITACORA_H_
