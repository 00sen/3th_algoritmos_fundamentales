/**

Act 3.3
Actividad Integral de BST

Roberto Ivan Estrada
A00834027
Luis Arturo Rendon
A01703572

 * Compilacion para ejecucion:
 *    g++ main.cpp Bitacora.cpp Registro.cpp
 * Ejecucion:
 *    ./a.out
 **/

#include "Bitacora.h"
#include <iostream>

int main() {
  Bitacora miBitacora;
  miBitacora.leerArchivo("bitacoraHeap.txt"); // Creación de heap sin ordernar
  miBitacora.heapSort();    // Aplicación de algoritmo HeapSort
  miBitacora.writeAll();    // Escribe la bitacora ordenada en el archivo .txt
  miBitacora.insertInAvl(); // Almacena en un AVL los registros
  miBitacora.avl.inorder(); // Imprimimos en consola las 10 ip con mas acceso y
                            // tambien las escribimos en el .txt
}