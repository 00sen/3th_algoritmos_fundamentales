#ifndef _BST_H_
#define _BST_H_

#include "BSTNode.h"
#include <iostream>

template <class T> class BST {
private:
  BSTNode<T> *root;
  BSTNode<T> *insertRecursive(BSTNode<T> *p, T value);
  void recursiveInorder(BSTNode<T> *p);
